
var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $http) {
  $http({
    method : "GET",
    url : " http://localhost:3000/users"
  }).then(function (response) {
      $scope.myData=response.data;
      $scope.id = response.id;
      $scope.firstname = response.firstname;
      $scope.email = response.email;
    });
});